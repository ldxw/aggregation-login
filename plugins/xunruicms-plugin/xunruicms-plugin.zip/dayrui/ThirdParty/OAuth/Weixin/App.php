<?php
// 接入商名称

return [
    'name' => '微信', // 接入商名称
    'help' => 587, // 帮助手册id
];