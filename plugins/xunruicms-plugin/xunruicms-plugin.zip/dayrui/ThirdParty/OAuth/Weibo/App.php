<?php
// 接入商名称

return [
    'name' => '微博', // 接入商名称
    'help' => 588, // 帮助手册id
];