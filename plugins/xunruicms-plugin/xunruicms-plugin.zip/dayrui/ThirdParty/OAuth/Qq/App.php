<?php
// 接入商名称

return [
    'name' => 'QQ', // 接入商名称
    'help' => 586, // 帮助手册id
];