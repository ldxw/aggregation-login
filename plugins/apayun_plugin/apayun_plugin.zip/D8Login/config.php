<?php
/**
 * Created by PhpStorm.
 * User: xiaoye
 * Email: 415907483@qq.com
 * Date: 2021/9/25
 * Time: 17:26
 */
return [
    'apiurl'        =>[
        'title' => '接口地址',
        'type'  => 'text',
        'value' => '',
    ],
    'appid'         =>[
        'title' => 'APPID',
        'type'  => 'text',
        'value' => '',
    ],
    'appkey'         =>  [
        'title' => 'APPKEY',
        'type'  => 'text',
        'value' => '',
    ],
];