<?php
return array(
    'name'  =>  '彩虹聚合登录',
    'icon'  =>  'clogin',
    'user'  =>  '彩虹',
    'mess'  =>  '彩虹聚合登录可以直接使用QQ、微信快捷登录方式。',
    'version' => '1.0'
);
