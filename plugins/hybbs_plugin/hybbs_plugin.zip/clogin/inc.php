<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
{"appurl":"","appid":"","appkey":"","autoreg":"0","opentype":["qq","wx"],"name":"clogin","gn":"op"}