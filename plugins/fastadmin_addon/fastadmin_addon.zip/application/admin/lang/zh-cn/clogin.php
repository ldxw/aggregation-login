<?php

return [
    'Id'           => 'ID',
    'User_id'      => '会员ID',
    'Platform'     => '登录方式',
    'Openid'       => '第三方账号ID',
    'Openname'     => '第三方会员昵称',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Logintime'    => '登录时间',
    'Expiretime'   => '过期时间'
];
