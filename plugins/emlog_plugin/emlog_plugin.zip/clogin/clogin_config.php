<?php $clogin_config=array (
  "apiurl" => "https://u.cccyun.cc/",
  "appid" => "",
  "appkey" => "",
  "openqq" => "0",
  "openwx" => "0",
) ?>